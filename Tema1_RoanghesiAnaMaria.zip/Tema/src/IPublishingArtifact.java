public interface IPublishingArtifact {

    public String Publish();
}
