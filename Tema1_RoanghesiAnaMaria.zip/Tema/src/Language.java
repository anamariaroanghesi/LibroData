public class Language {
    int ID;
    String code;
    String name;

    public Language(int ID, String code, String name) {
        this.ID = ID;
        this.code = code;
        this.name = name;
    }
}
